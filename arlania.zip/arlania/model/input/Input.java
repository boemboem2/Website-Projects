package com.arlania.model.input;

import com.arlania.world.entity.impl.player.Player;


public class Input {
	
	public void handleSyntax(Player player, String text) {
		
	}

	public void handleAmount(Player player, int amount) {
		
	}
	
}
