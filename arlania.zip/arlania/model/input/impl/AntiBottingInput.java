package com.arlania.model.input.impl;

import com.arlania.model.input.EnterAmount;
import com.arlania.util.Misc;
import com.arlania.world.entity.impl.player.Player;

public class AntiBottingInput extends EnterAmount {
	
	
	@Override
	public void handleSyntax(Player player, String syntax) {
		String attempt = syntax;
		
		
	}
	
	

}