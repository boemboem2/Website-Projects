package com.arlania.model;

public enum GraphicHeight {

	LOW,
	
	MIDDLE,
	
	HIGH;
}
