package com.arlania.model;

/**
 * Represents a player's sex aka gender.
 * 
 * @author relex lawl
 */

public enum Gender {
	
	MALE,
	FEMALE;
}
