package com.arlania.world.content.skill.impl.farming;

public class Calquat {
}
