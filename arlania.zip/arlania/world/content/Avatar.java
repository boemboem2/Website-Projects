package com.arlania.world.content;


/*
 * Avatar that spawns every hour in wilderness
 * @Author Bas - www.Arlania.com
 */

public class Avatar {







}
