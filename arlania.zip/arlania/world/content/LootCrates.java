package com.arlania.world.content;

import com.arlania.model.GameObject;
import com.arlania.world.content.ShootingStar.CrashedStar;
import com.arlania.world.entity.impl.player.Player;

/*
 * Spawns Loot crates in wildenress every 15 minutes.
 * @author Bas - www.Arlania.com
 */

public class LootCrates {
	
	public static CrashedStar CRASHED_STAR = null;

	
	public static void lootCrate (Player player) {
		
		
	}
 

}
